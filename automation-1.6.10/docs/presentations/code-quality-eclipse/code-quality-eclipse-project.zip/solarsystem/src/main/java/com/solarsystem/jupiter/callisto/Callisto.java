package com.solarsystem.jupiter.callisto;

import com.solarsystem.jupiter.IPlanet;

/**
 * 
 * @author Levent Gurses
 * 
 * With a diameter of over 4,800 km (2,985 miles), Callisto is the third largest
 * satellite in the solar system and is almost the size of Mercury. Callisto is
 * the outermost of the Galilean satellites, and orbits beyonds Jupiter's main
 * radiation belts. It has the lowest density of the Galilean satellites (1.86
 * grams/cubic centimeter). Its interior is probably similar to Ganymede except
 * the inner rocky core is smaller, and this core is surrounded by a large icy
 * mantle. Callisto's surface is the darkest of the Galileans, but it is twice
 * as bright as our own Moon.
 * 
 * Callisto is the most heavily cratered object in the solar system. It is
 * thought to be a long dead world, with a nearly complete absence of any
 * geologic activity on its surface. In fact, Callisto is the only body greater
 * than 1000 km in diameter in the solar system that has shown no signs of
 * undergoing any extensive resurfacing since impacts have molded its surface.
 * With a surface age of about 4 billion years, Callisto has the oldest
 * landscape in the solar system.
 * 
 * Copyright � 1997-1999 by Calvin J. Hamilton. www.planetscapes.com
 * 
 */

public class Callisto {

	// Instance of Jupiter
	private IPlanet jupiter;

	// Distance to Jupiter in kilometers
	private double distanceToJupiter = 1883000.0;

	// Equatorial Radius in kilometers
	private double radius = 2403.0;

	// Mass in kilograms
	private double mass = 107593000000000000000000.0;

	// Constructor
	public Callisto(IPlanet jupiter) {
		this.jupiter = jupiter;
	}

	public double getDistanceToJupiter() {
		return this.distanceToJupiter;
	}

	public double getRadius() {
		return this.radius;
	}

	public double getMass() {
		return this.mass;
	}

	public double getDistanceToSun() {
		return this.getDistanceToJupiter() + this.jupiter.getDistanceToSun();
	}
}
