package com.solarsystem.jupiter.europa;

import com.solarsystem.jupiter.IPlanet;

/**
 * 
 * @author Levent Gurses
 * 
 * Europa [yur-ROH-pah] is a strange looking moon of Jupiter with a large number
 * of intersecting features. It is unlike Callisto and Ganymede with their
 * heavily cratered crusts. Europa has almost a complete absence of craters as
 * well as almost no vertical relief. As one scientist put it, the features
 * "might have been painted on with a felt marker". There is a possibility that
 * Europa may be internally active due to tidal heating at a level one-tenth or
 * less that of Io. Models of Europa's interior show that beneath a thin 5 km (3
 * miles) crust of water ice, Europa may have oceans as deep as 50 km (30 miles)
 * or more. The visible markings on Europa could be a result of global expansion
 * where the crust could have fractured, filled with water and froze.
 * 
 * Copyright � 1997-1999 by Calvin J. Hamilton. www.planetscapes.com
 * 
 */

public class Europa {

	// Instance of Jupiter
	private IPlanet jupiter;

	// Distance to Jupiter in kilometers
	private double distanceToJupiter = 671000.0;

	// Equatorial Radius in kilometers
	private double radius = 1565.0;

	// Mass in kilograms
	private double mass = 47998200000000000000000.0;

	// Constructor
	public Europa(IPlanet jupiter) {
		this.jupiter = jupiter;
	}

	public double getDistanceToJupiter() {
		return this.distanceToJupiter;
	}

	public double getRadius() {
		return this.radius;
	}

	public double getMass() {
		return this.mass;
	}

	public double getDistanceToSun() {
		return this.getDistanceToJupiter() + this.jupiter.getDistanceToSun();
	}
}
