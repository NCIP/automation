package com.solarsystem.jupiter.ganymede;

import com.solarsystem.jupiter.IPlanet;

/**
 * 
 * @author Levent Gurses
 * 
 * Ganymede [GAN-ee-meed] is the largest moon of Jupiter and is the largest in
 * our solar system with a diameter of 5,262 km (3,280 miles). If Ganymede
 * orbited the Sun instead of Jupiter it could be classified as a planet. Like
 * Callisto, Ganymede is most likely composed of a rocky core with a water/ice
 * mantle and a crust of rock and ice. Its low density of 1.94 gm/cm 3,
 * indicates that the core takes up about 50% of the satellite's diameter.
 * Ganymede's mantle is most likely composed of ice and silicates, and its crust
 * is probably a thick layer of water ice.
 * 
 * Ganymede has no known atmosphere, but recently the Hubble Space Telescope
 * detected ozone at its surface. The amount of ozone is small as compared to
 * Earth. It is produced as charged particles trapped in Jupiter's magnetic
 * field rain down onto the surface of Ganymede. As the charged particles
 * penetrate the icy surface, particles of water are disrupted leading to ozone
 * production. This chemical process hints that Ganymede probably has a thin
 * tenuous oxygen atmosphere like that detected on Europa.
 * 
 * Ganymede has had a complex geological histroy. It has mountains, valleys,
 * craters and lava flows. Ganymede is mottled by both light and dark regions.
 * It is heavily cratered, especially in the dark regions, implying ancient
 * origin. The bright regions show a different kind of terrain - one which is
 * grooved with ridges and troughs. These features form complex patterns, have a
 * vertical relief of a few hundred meters, and run for thousands of kilometers.
 * The grooved features were apparently formed more recently than the dark
 * cratered area, perhaps by tension from global tectonic processes. The real
 * reason is unknown; however, local crust spreading does appear to have taken
 * place, causing the crust to shear and separate.
 * 
 * Copyright � 1997-1999 by Calvin J. Hamilton. www.planetscapes.com
 * 
 */

public class Ganymede {

	// Instance of Jupiter
	private IPlanet jupiter;

	// Distance to Jupiter in kilometers
	private double distanceToJupiter = 1070000.0;

	// Equatorial Radius in kilometers
	private double radius = 2634.0;

	// Mass in kilograms
	private double mass = 148186000000000000000000.0;

	// Constructor
	public Ganymede(IPlanet jupiter) {
		this.jupiter = jupiter;
	}

	public double getDistanceToJupiter() {
		return this.distanceToJupiter;
	}

	public double getRadius() {
		return this.radius;
	}

	public double getMass() {
		return this.mass;
	}

	public double getDistanceToSun() {
		return this.getDistanceToJupiter() + this.jupiter.getDistanceToSun();
	}
}
