package com.solarsystem.jupiter;

import junit.framework.TestCase;

public class JupiterBusinessManagerTest extends TestCase {

	JupiterBusinessManager jupiterBusinessManager = new JupiterBusinessManager();

	public void testAdd() {
		int result = jupiterBusinessManager.add(1, 1);
		assertEquals(2, result);
	}

	// public void testAddMinValue() {
	// int result = jupiterBusinessManager.add(Integer.MIN_VALUE, 1);
	// assertEquals(1 + Integer.MIN_VALUE, result);
	// }

	public void testDivide() {
		double divideResult = jupiterBusinessManager.divide(1, 2);
		assertEquals(0.5d, divideResult, 0.0d);
	}

	public void testCatchesException() {
		jupiterBusinessManager.catchesException();
	}

	public void testMultiply() {
		assertEquals(10, jupiterBusinessManager.multiply(5, 2));
		assertEquals(0, jupiterBusinessManager.multiply(100, 0));
	}

	public void testJustALoop() {
		assertEquals(2, jupiterBusinessManager.justALoop());
	}

	public void testSubtract() {
		assertEquals(3, jupiterBusinessManager.substract(5, 2));
	}

}
