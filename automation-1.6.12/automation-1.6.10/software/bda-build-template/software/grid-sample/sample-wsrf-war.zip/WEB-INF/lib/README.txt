Any jar library placed in this folder will be automaticaly included into your services
classpath.  These files will also be deployed into the web service container.