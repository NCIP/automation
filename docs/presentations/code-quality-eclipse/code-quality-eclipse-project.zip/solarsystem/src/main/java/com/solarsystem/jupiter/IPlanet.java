package com.solarsystem.jupiter;

public interface IPlanet {

	/* (non-Javadoc)
	 * @see com.solarsystem.jupiter.IJupiter#getDistanceToSun()
	 */
	public abstract double getDistanceToSun();

	/* (non-Javadoc)
	 * @see com.solarsystem.jupiter.IJupiter#getRadius()
	 */
	public abstract double getRadius();

	/* (non-Javadoc)
	 * @see com.solarsystem.jupiter.IJupiter#getMass()
	 */
	public abstract double getMass();

}