package com.solarsystem.jupiter;

/**
 * 
 * @author Levent Gurses
 * 
 * 
 * The most massive planet in our solar system, with four planet-sized moons and
 * many smaller moons, Jupiter forms a kind of miniature solar system. Jupiter
 * resembles a star in composition. In fact, if it had been about eighty times
 * more massive, it would have become a star rather than a planet.
 * 
 * On January 7, 1610, using his primitive telescope, astronomer Galileo Galilei
 * saw four small 'stars' near Jupiter. He had discovered Jupiter's four largest
 * moons, now called Io, Europa, Ganymede, and Callisto. Collectively, these
 * four moons are known today as the Galilean satellites.
 * 
 * Galileo would be astonished at what we have learned about Jupiter and its
 * moons in the past 30 years. Io is the most volcanically active body in our
 * solar system. Ganymede is the largest planetary moon and is the only moon in
 * the solar system known to have its own magnetic field. A liquid ocean may lie
 * beneath the frozen crust of Europa. Icy oceans may also lie deep beneath the
 * crusts of Callisto and Ganymede. In 2003 alone, astronomers discovered 23 new
 * moons orbiting the giant planet, giving Jupiter a total moon count of 63 -
 * the most in the solar system. The numerous small outer moons may be asteroids
 * captured by the giant planet's gravity.
 * 
 * Copyright � 1997-1999 by Calvin J. Hamilton. www.planetscapes.com
 * 
 */

public class Jupiter implements IPlanet {

	// Distance to Sun in kilometers
	private static double distanceToSun = 778412020;

	// Equatorial Radius in kilometers
	private static double radius = 71492;

	// Mass in kilograms
	private static double mass = 1898700000000000000000000000.0;

	/* (non-Javadoc)
	 * @see com.solarsystem.jupiter.IJupiter#getDistanceToSun()
	 */
	/* (non-Javadoc)
	 * @see com.solarsystem.jupiter.IPlanet#getDistanceToSun()
	 */
	public double getDistanceToSun() {
		return distanceToSun;
	}

	/* (non-Javadoc)
	 * @see com.solarsystem.jupiter.IJupiter#getRadius()
	 */
	/* (non-Javadoc)
	 * @see com.solarsystem.jupiter.IPlanet#getRadius()
	 */
	public double getRadius() {
		return radius;
	}

	/* (non-Javadoc)
	 * @see com.solarsystem.jupiter.IJupiter#getMass()
	 */
	/* (non-Javadoc)
	 * @see com.solarsystem.jupiter.IPlanet#getMass()
	 */
	public double getMass() {
		return mass;
	}
}
