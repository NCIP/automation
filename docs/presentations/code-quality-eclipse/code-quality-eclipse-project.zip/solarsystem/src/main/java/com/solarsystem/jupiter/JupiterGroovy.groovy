package com.solarsystem.jupiter
import com.solarsystem.jupiter.IPlanet

class JupiterGroovy implements IPlanet {


	public double getDistanceToSun() {
		return 454545.00;
	}

	public double getRadius() {
		return 454545.00;
	}

	public double getMass() {
		return 454545.00;
	}

}