package com.solarsystem.jupiter.io;

import com.solarsystem.jupiter.IPlanet;

/**
 * 
 * @author Levent Gurses
 * 
 * Looking like a giant pizza covered with melted cheese and splotches of tomato
 * and ripe olives, Io is the most volcanically active body in the solar system.
 * Volcanic plumes rise 300 kilometers (190 miles) above the surface, with
 * material spewing out at nearly half the required escape velocity.
 * 
 * A bit larger than Earth's moon, Io is the third largest of Jupiter's moons,
 * and the fifth one in distance from the planet.
 * 
 * Although Io always points the same side toward Jupiter in its orbit around
 * the giant planet, the large moons Europa and Ganymede perturb Io's orbit into
 * an irregularly elliptical one. Thus, in its widely varying distances from
 * Jupiter, Io is subjected to tremendous tidal forces. These forces cause Io's
 * surface to bulge up and down (or in and out) by as much as 100 meters (330
 * feet)! Compare these tides on Io's solid surface to the tides on Earth's
 * oceans. On Earth, in the place where tides are highest, the difference
 * between low and high tides is only 18 meters (60 feet), and this is for
 * water, not solid ground!
 * 
 * This tidal pumping generates a tremendous amount of heat within Io, keeping
 * much of its subsurface crust in liquid form, seeking any available escape
 * route to the surface to relieve the pressure. Thus, the surface of Io is
 * constantly renewing itself, filling in any impact craters with molten lava
 * lakes and spreading smooth new floodplains of liquid rock. The composition of
 * this material is not yet entirely clear, but theories suggest that it is
 * largely molten sulfur and its compounds (which would account for the
 * varigated coloring) or silicate rock (which would better account for the
 * apparent temperatures, which may be too hot to be sulfur). Sulfur dioxide is
 * the primary constituent of a thin atmosphere on Io. It has no water to speak
 * of, unlike the other, colder Galilean moons. Data from the Galileo spacecraft
 * indicates that an iron core may form Io's center, thus giving Io its own
 * magnetic field.
 * 
 * Io's orbit, keeping it at more or less a cozy 422,000 kilometers (262,000
 * miles) from Jupiter, cuts across the planet's powerful magnetic lines of
 * force, thus turning Io into a electric generator. Io can develop 400,000
 * volts across itself and create an electric current of 3 million amperes. This
 * current takes the path of least resistance along Jupiter's magnetic field
 * lines to the planet's surface, creating lightning in Jupiter's upper
 * atmosphere.
 * 
 * As Jupiter rotates, it takes its magnetic field around with it, sweeping past
 * Io and stripping off about 1,000 kilograms (1 ton) of Io's material every
 * second! This material becomes ionized in the magnetic field and forms a
 * doughnut-shaped cloud of intense radiation referred to as a plasma torus.
 * Some of the ions are pulled into Jupiter's atmosphere along the magnetic
 * lines of force and create auroras in the planet's upper atmosphere. It is the
 * ions escaping from this torus that inflate Jupiter's magnetosphere to over
 * twice the size we would expect.
 * 
 * Copyright � 1997-1999 by Calvin J. Hamilton. www.planetscapes.com
 * 
 */

public class Io {

	// Instance of Jupiter
	private IPlanet jupiter;

	// Distance to Jupiter in kilometers
	private double distanceToJupiter = 422000.0;

	// Equatorial Radius in kilometers
	private double radius = 1820.0;

	// Mass in kilograms
	private double mass = 89316000000000000000000.0;

	// Constructor
	public Io(IPlanet jupiter) {
		this.jupiter = jupiter;
	}

	public double getDistanceToJupiter() {
		return this.distanceToJupiter;
	}

	public double getRadius() {
		return this.radius;
	}

	public double getMass() {
		return this.mass;
	}

	public double getDistanceToSun() {
		return this.getDistanceToJupiter() + this.jupiter.getDistanceToSun();
	}
}
