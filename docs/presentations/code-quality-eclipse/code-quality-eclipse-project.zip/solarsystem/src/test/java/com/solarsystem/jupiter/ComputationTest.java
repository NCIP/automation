package com.solarsystem.jupiter;

import junit.framework.TestCase;

public class ComputationTest extends TestCase {

	Computation computation = new Computation();

	/**
	 * this is a test that tests exactly what it should
	 * 
	 */
	public void testAdd() {
		int addResult = computation.add(1, 1);
		assertEquals(2, addResult);
	}

	/**
	 * this is a test that doesn't test what it should do.
	 * 
	 */
	public void testSubstract() {
		// do nothing
	}

	/**
	 * this is a test that tests its parts only partially
	 * 
	 */
	public void testDivide() {
		double divideResult = computation.divide(1, 2);
		assertEquals(0.5d, divideResult, 0.0d);
	}

	public void testCatchesException() {
		computation.catchesException();
	}

	public void testMultiply() {
		assertEquals(10, computation.multiply(5, 2));
		assertEquals(0, computation.multiply(100, 0));
	}

	public void testJustALoop() {
		assertEquals(2, computation.justALoop());
	}

	public void testSubtract() {
		assertEquals(3, computation.substract(5, 2));
	}

}
