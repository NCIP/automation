USE @database.name@;

DROP TABLE IF EXISTS config_parameter;