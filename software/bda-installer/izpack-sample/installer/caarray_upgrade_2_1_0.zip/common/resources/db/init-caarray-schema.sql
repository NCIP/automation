CREATE TABLE config_parameter (
  param VARCHAR(255) NOT NULL,
  raw_value VARCHAR(4000),
  PRIMARY KEY (param)
 )Type=InnoDB;