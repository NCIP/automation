update config_parameter set raw_value = 'NCICB@pop.nci.nih.gov' where param = 'REG_EMAIL_TO';
update config_parameter set raw_value = 'NCICB@pop.nci.nih.gov' where param = 'EMAIL_FROM';
update config_parameter set raw_value = '/local/content/caarray' where param = 'STRUTS_MULTIPART_SAVEDIR';